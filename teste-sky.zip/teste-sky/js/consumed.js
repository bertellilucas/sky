$(document).ready(function() {
    getData();
})

const montaMovie = (movieList) => {

    const start = `<div class="row">`;
    const end = `</div>`;

    let content = start;

    movieList.forEach((movie, i) => {
        if (i % 9 !== 0) {
            content += `<div class="movie col-sm-4 col-md-4 col-lg-4 py-3 efeito">
                <img width="200" height="200" class="image img-fluid" src="${movie.images[0].url}" />
            </div>`
        }
        if (i > 0 && i % 9 === 0) {
            content += `
            
            <div class="movie col-sm-4 col-md-4 col-lg-4 py-3 efeito">
                <img width="200" height="200" class="image img-fluid" src="${movie.images[0].url}" />
            </div>`
            content += end;
            content += start;
        }
    })

    $('#movies-all .movies-list').append(content);
}

const montaHighlits = (movie, i) => {

    return ` <img class="gallery-item" src="${movie.images[0].url}">`
}



const getData = async() => {
    let data = null;
    $.ajax('https://sky-frontend.herokuapp.com/movies').done(res => {
        data = res

        let highlights = data.filter(category => category.type === 'highlights')[0];
        let carousel = data.filter(category => category.type === 'carousel-portrait')[0];
        let menu = data.filter(category => category.type === 'menu')[0];
    
    
        highlights.items.forEach((highlight, i) => {
            
            $('.gallery-container').append(montaHighlits(highlight, i));
        })

        startCarousel();
    
        montaMovie(carousel.movies)
    });
    


}